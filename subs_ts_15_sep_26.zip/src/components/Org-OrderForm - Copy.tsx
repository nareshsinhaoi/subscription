import { useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { SiteHeader } from "@/components/SiteHeader";
import {
  COUNTRIES,
  INDIAN_STATES,
  PAYMENT_MODES,
} from "@/lib/subscription-data";
import {
  getDraft,
  saveDraft,
  savePlacedOrder,
  generateSessionId,
  type CustomerDetails,
  type OrderDraft,
} from "@/lib/order-store";

const MONTHS = [
  ["01", "Jan"], ["02", "Feb"], ["03", "Mar"], ["04", "Apr"], ["05", "May"], ["06", "Jun"],
  ["07", "Jul"], ["08", "Aug"], ["09", "Sep"], ["10", "Oct"], ["11", "Nov"], ["12", "Dec"],
];

const emptyCustomer: CustomerDetails = {
  fname: "", lname: "", sex: "M", day1: "", month1: "", year1: "",
  address1: "", pin: "", state: "", country: "", city: "",
  phoneoff: "", phoneres: "", email: "", occupa: "", desig: "", org: "",
  paymentchoice: "PAYTM",
};

export function OrderForm({ scope }: { scope: "domestic" | "international" }) {
  const navigate = useNavigate();
  const [draft, setDraft] = useState<OrderDraft | null>(null);
  const [form, setForm] = useState<CustomerDetails>(emptyCustomer);
  const [errors, setErrors] = useState<Record<string, boolean>>({});
  const [shake, setShake] = useState(false);

  useEffect(() => {
    const d = getDraft();
    if (!d) {
      navigate({ to: scope === "domestic" ? "/bundle-subscription" : "/international-subscription" });
      return;
    }
    setDraft(d);
  }, [navigate, scope]);

  const set = (key: keyof CustomerDetails, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: false }));
  };

  const digitsOnly = (key: keyof CustomerDetails) => (value: string) =>
    set(key, value.replace(/\D/g, ""));

  function validate() {
    const next: Record<string, boolean> = {};
    const required: (keyof CustomerDetails)[] = [
      "fname", "lname", "address1", "pin", "city", "phoneoff", "email", "occupa", "desig",
    ];
    for (const key of required) if (!String(form[key] ?? "").trim()) next[key] = true;
    if (!form.day1 || !form.month1 || !form.year1) next["dob"] = true;
    if (scope === "domestic" && !form.state) next["state"] = true;
    if (scope === "international" && !form.country) next["country"] = true;
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next["email"] = true;
    setErrors(next);
    if (Object.keys(next).length) {
      setShake(true);
      setTimeout(() => setShake(false), 500);
      return false;
    }
    return true;
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!draft || !validate()) return;
    saveDraft(draft);
    savePlacedOrder({
      order: draft,
      customer: form,
      sessionId: generateSessionId(),
      merchantId: "",
      status: "PENDING",
      dateSub: new Date().toISOString(),
    });
    navigate({ to: "/payment" });
  }

  if (!draft) return null;

  const years: number[] = [];
  const thisYear = new Date().getFullYear();
  for (let y = thisYear - 10; y >= thisYear - 100; y--) years.push(y);
  const formattedTotal = `${draft.currencySymbol} ${draft.amt.toLocaleString(draft.languagesSymbol)}`;

  return (
    <div className="ol-page order-form-page">
      <SiteHeader />
      <main className="ol-container-narrow order-form-shell">
        <header className="order-form-header">
          <div>
            <span className="order-form-kicker">Secure subscription checkout</span>
            <h1>Complete your order</h1>
            <p>Enter your details below to continue to payment.</p>
          </div>
          <div className="secure-checkout-mark" aria-label="Secure checkout">
            <span aria-hidden="true">⌾</span>
            <span>Secure checkout</span>
          </div>
        </header>

        <form onSubmit={submit} noValidate>
          <div className="order-summary">
            <div className="order-summary-heading">
              <div>
                <span className="summary-eyebrow">Your selection</span>
                <h2 className="summary-title">Order Summary</h2>
              </div>
              <div className="summary-total">
                <span>Total</span>
                <strong>{formattedTotal}</strong>
              </div>
            </div>
            <div className="summary-content">
              <ul className="order-item-list">
                {draft.selectionList.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              {draft.gift && (
                <p className="order-benefit">
                  <span aria-hidden="true">✓</span>
                  <strong>{draft.gift}</strong>
                </p>
              )}
            </div>
          </div>

          <div className={`form-container ${shake ? "shake" : ""}`}>
            <div className="section-heading">
              <span>1</span>
              <div>
                <h2 className="section-title">Mailing Details</h2>
                <p>Fields marked with an asterisk are required.</p>
              </div>
            </div>

            <div className="form-row">
              <div className="form-col">
                <label className="required" htmlFor="fname">First Name</label>
                <input id="fname" maxLength={50} value={form.fname} onChange={(e) => set("fname", e.target.value)} />
                {errors["fname"] && <div className="validation-error">Please enter your first name</div>}
              </div>
              <div className="form-col">
                <label className="required" htmlFor="lname">Last Name</label>
                <input id="lname" maxLength={50} value={form.lname} onChange={(e) => set("lname", e.target.value)} />
                {errors["lname"] && <div className="validation-error">Please enter your last name</div>}
              </div>
            </div>

            <div className="form-group">
              <label className="required">Gender</label>
              <div className="radio-group">
                {[["M", "Male"], ["F", "Female"]].map(([value, label]) => (
                  <div className="radio-option" key={value}>
                    <input
                      type="radio"
                      id={value}
                      name="sex"
                      checked={form.sex === value}
                    onChange={() => set("sex", value ?? "")}
                    />
                    <label htmlFor={value} className="label-radio">{label}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="form-group">
              <label className="required">Date of Birth</label>
              <div className="dob-group">
                <select value={form.day1} onChange={(e) => set("day1", e.target.value)}>
                  <option value="">Day</option>
                  {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
                <select value={form.month1} onChange={(e) => set("month1", e.target.value)}>
                  <option value="">Month</option>
                  {MONTHS.map(([v, l]) => (
                    <option key={v} value={v}>{l}</option>
                  ))}
                </select>
                <select value={form.year1} onChange={(e) => set("year1", e.target.value)}>
                  <option value="">Year</option>
                  {years.map((y) => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>
              {errors["dob"] && <div className="validation-error">Please select your complete date of birth</div>}
            </div>

            <div className="form-group">
              <label className="required" htmlFor="address1">
                {scope === "domestic" ? "Delivery Address" : "Mailing Address"}
              </label>
              <textarea
                id="address1"
                className="class-textarea"
                placeholder="Enter your mailing address"
                value={form.address1}
                onChange={(e) => set("address1", e.target.value)}
              />
              {errors["address1"] && <div className="validation-error">Please enter your mailing address</div>}
            </div>

            <div className="form-row">
              <div className="form-col">
                <label className="required" htmlFor="pin">Pin/Zip Code</label>
                <input
                  id="pin"
                  maxLength={10}
                  placeholder="Without spaces"
                  value={form.pin}
                  onChange={(e) => set("pin", e.target.value)}
                />
                {errors["pin"] && <div className="validation-error">Please enter a valid pin/zip code</div>}
              </div>
              <div className="form-col">
                {scope === "domestic" ? (
                  <>
                    <label className="required" htmlFor="state">State</label>
                    <select id="state" value={form.state} onChange={(e) => set("state", e.target.value)}>
                      <option value="">Select state</option>
                      {INDIAN_STATES.map((s) => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                    {errors["state"] && <div className="validation-error">Please select state.</div>}
                  </>
                ) : (
                  <>
                    <label className="required" htmlFor="country">Country</label>
                    <select id="country" value={form.country} onChange={(e) => set("country", e.target.value)}>
                      <option value="">Select country</option>
                      {COUNTRIES.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                    {errors["country"] && <div className="validation-error">Please select your country</div>}
                  </>
                )}
              </div>
            </div>

            <div className="form-row">
              <div className="form-col">
                <label className="required" htmlFor="city">City</label>
                <input id="city" maxLength={99} value={form.city} onChange={(e) => set("city", e.target.value)} />
                {errors["city"] && <div className="validation-error">Please enter your city name</div>}
              </div>
              <div className="form-col">
                <label className="required" htmlFor="phoneoff">Mobile</label>
                <input
                  id="phoneoff"
                  maxLength={12}
                  value={form.phoneoff}
                  onChange={(e) => digitsOnly("phoneoff")(e.target.value)}
                />
                {errors["phoneoff"] && <div className="validation-error">Please enter your mobile number</div>}
              </div>
            </div>

            <div className="form-row">
              <div className="form-col">
                <label htmlFor="phoneres">Phone (Residence)</label>
                <input
                  id="phoneres"
                  maxLength={12}
                  value={form.phoneres}
                  onChange={(e) => digitsOnly("phoneres")(e.target.value)}
                />
              </div>
              <div className="form-col">
                <label className="required" htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  maxLength={150}
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={(e) => set("email", e.target.value)}
                />
                {errors["email"] && <div className="validation-error">Please enter a valid email address</div>}
              </div>
            </div>

            <div className="form-row">
              <div className="form-col">
                <label className="required" htmlFor="occupa">
                  {scope === "domestic" ? "Occupation" : "Field of work"}
                </label>
                <input id="occupa" maxLength={150} value={form.occupa} onChange={(e) => set("occupa", e.target.value)} />
                {errors["occupa"] && <div className="validation-error">Please enter your occupation</div>}
              </div>
              <div className="form-col">
                <label className="required" htmlFor="desig">
                  {scope === "domestic" ? "Designation" : "Level of seniority"}
                </label>
                <input id="desig" maxLength={150} value={form.desig} onChange={(e) => set("desig", e.target.value)} />
                {errors["desig"] && <div className="validation-error">Please enter your designation</div>}
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="org">Organization</label>
              <input id="org" maxLength={150} value={form.org} onChange={(e) => set("org", e.target.value)} />
            </div>

            <div className="payment-section">
              <div className="section-heading payment-heading">
                <span>2</span>
                <div>
                  <h2 className="section-title">Payment Options</h2>
                  <p>Select your preferred secure payment service.</p>
                </div>
              </div>
              <div className="radio-group payment-options" role="radiogroup" aria-label="Payment options">
                {PAYMENT_MODES.map((m) => (
                  <div className={`radio-option payment-option ${form.paymentchoice === m.value ? "selected" : ""}`} key={m.value}>
                    <input
                      type="radio"
                      id={m.value}
                      name="paymentchoice"
                      checked={form.paymentchoice === m.value}
                      onChange={() => set("paymentchoice", m.value)}
                    />
                    <label htmlFor={m.value} className="label-radio">
                      <span className="payment-option-name">{m.label}</span>
                      <span className="payment-option-note">Cards, UPI and net banking</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>

            <div className="btn-container">
              <button type="submit" className="submit-btn">
                <span aria-hidden="true">🔒</span>
                Pay securely · {formattedTotal}
              </button>
            </div>

            <div className="payment-info">
              Your payment is encrypted and processed by your selected payment service.
            </div>
          </div>
          <footer className="order-form-footer">
            <a href="https://subscription.outlookindia.com/newoffer/terms-and-conditions-international.html" target="_blank" rel="noreferrer">
              Terms and Conditions
            </a>
            <span>Outlook Group</span>
          </footer>
        </form>
      </main>
    </div>
  );
}
