import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { SiteHeader } from "@/components/SiteHeader";
import { MERCHANT_IDS } from "@/lib/subscription-data";
import { getPlacedOrder, savePlacedOrder, type PlacedOrder } from "@/lib/order-store";

export const Route = createFileRoute("/payment")({
  head: () => ({
    meta: [
      { title: "Payment — Outlook Subscription" },
      { name: "description", content: "Confirm and pay for your Outlook magazine subscription." },
      { property: "og:title", content: "Payment — Outlook Subscription" },
      { property: "og:description", content: "Confirm and pay for your Outlook magazine subscription." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PaymentPage,
});

function PaymentPage() {
  const navigate = useNavigate();
  const [placed, setPlaced] = useState<PlacedOrder | null>(null);
  const [stage, setStage] = useState<"review" | "processing" | "done">("review");

  useEffect(() => {
    const p = getPlacedOrder();
    if (!p) {
      navigate({ to: "/bundle-subscription" });
      return;
    }
    setPlaced(p);
  }, [navigate]);

  if (!placed) return null;

  const { order, customer, sessionId } = placed;
  const merchantId = MERCHANT_IDS[customer.paymentchoice] ?? "";

  function payNow() {
    setStage("processing");
    setTimeout(() => {
      const updated: PlacedOrder = {
        ...placed!,
        merchantId,
        status: "SUCCESS",
        dateSub: new Date().toISOString(),
      };
      savePlacedOrder(updated);
      setPlaced(updated);
      setStage("done");
    }, 1800);
  }

  const row = (label: string, value: string) => (
    <div className="deal-row" key={label}>
      <span style={{ fontWeight: 600 }}>{label}</span>
      <span style={{ textAlign: "right" }}>{value}</span>
    </div>
  );

  return (
    <div className="ol-page" style={{ padding: 20 }}>
      <SiteHeader />
      <div className="ol-container-narrow" style={{ marginTop: 20 }}>
        <div className="ol-header">
          <h1>{stage === "done" ? "Payment Successful" : "Confirm & Pay"}</h1>
          <p className="subtitle">
            {stage === "done"
              ? "Your subscription order has been recorded"
              : `Paying through ${customer.paymentchoice}`}
          </p>
        </div>

        <div className="order-summary">
          <h2 className="summary-title">Order Summary</h2>
          <ul>
            {order.selectionList.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          {order.gift && (
            <p>
              <strong>{order.gift}</strong>
            </p>
          )}
        </div>

        <div className="form-container">
          <h2 className="section-title">Transaction Details</h2>
          {row("Reference (Session ID)", sessionId)}
          {row("Subscriber", `${customer.fname} ${customer.lname}`)}
          {row("Email", customer.email)}
          {row("Mobile", customer.phoneoff)}
          {row(
            "Delivery",
            `${customer.address1}, ${customer.city} ${customer.pin}, ${
              customer.state || customer.country || ""
            }`,
          )}
          {row("Payment Mode", `${customer.paymentchoice} (Merchant ID ${merchantId})`)}
          {row("Duration", order.dura)}
          {row("Status", placed.status)}
          <div className="deal-row">
            <span style={{ fontWeight: 700 }}>Amount Payable</span>
            <span style={{ fontWeight: 700, color: "#d60810", fontSize: "1.2rem" }}>
              {order.currencySymbol} {order.amt.toLocaleString(order.languagesSymbol)}
            </span>
          </div>

          {stage === "review" && (
            <button type="button" className="submit-btn" onClick={payNow}>
              Pay {order.currencySymbol} {order.amt.toLocaleString(order.languagesSymbol)} with{" "}
              {customer.paymentchoice}
            </button>
          )}

          {stage === "processing" && (
            <p className="payment-info">
              Redirecting to {customer.paymentchoice}… please do not refresh this page.
            </p>
          )}

          {stage === "done" && (
            <>
              <p className="payment-info">
                Thank you! A confirmation has been sent to {customer.email}. Please keep reference{" "}
                <strong>{sessionId}</strong> for any queries.
              </p>
              <button
                type="button"
                className="submit-btn"
                onClick={() =>
                  navigate({
                    to:
                      order.scope === "domestic"
                        ? "/bundle-subscription"
                        : "/international-subscription",
                  })
                }
              >
                Start a new subscription
              </button>
            </>
          )}

          <div className="payment-info">
            Payment gateways are running in test mode — no money is charged.
          </div>
        </div>
      </div>
    </div>
  );
}
