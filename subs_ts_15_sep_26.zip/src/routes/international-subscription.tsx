import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";

import { SiteHeader } from "@/components/SiteHeader";
import {
  BANNERS,
  CURRENCIES,
  INTL_MAGAZINES,
  convertCurrency,
} from "@/lib/subscription-data";
import { saveDraft } from "@/lib/order-store";

export const Route = createFileRoute("/international-subscription")({
  head: () => ({
    meta: [
      { title: "Outlook Magazine Subscription for International Readers" },
      {
        name: "description",
        content:
          "Subscribe to Outlook magazines from anywhere in the world. Print and digital editions with prices in your local currency.",
      },
      { property: "og:title", content: "Outlook Magazine Subscription — International" },
      {
        property: "og:description",
        content: "Print and digital Outlook magazine plans for readers outside India.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: InternationalSubscription,
});

type Edition = "print" | "digital1" | "digital2";
type Picked = Record<string, Edition | "">;

function InternationalSubscription() {
  const navigate = useNavigate();
  const [currency, setCurrency] = useState("USD");
  const [picked, setPicked] = useState<Picked>({});
  const [error, setError] = useState(false);

  const symbol = CURRENCIES[currency]!.symbol;

  const priceOf = (mag: (typeof INTL_MAGAZINES)[number], edition: Edition) => {
    const base =
      edition === "print" ? mag.print1 : edition === "digital1" ? mag.digital1 : mag.digital2;
    return convertCurrency(base, currency);
  };

  const summary = useMemo(() => {
    const items: string[] = [];
    let total = 0;
    for (const mag of INTL_MAGAZINES) {
      const edition = picked[mag.key];
      if (!edition) continue;
      const price = priceOf(mag, edition);
      total += price;
      const label =
        edition === "print"
          ? "1 Year - Print Edition"
          : edition === "digital1"
            ? "1 Year - Digital Edition"
            : "2 Years - Digital Edition";
      items.push(`${mag.name} - ${label} at ${symbol}${price}`);
    }
    return items.length ? { items, total } : null;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [picked, currency]);

  function proceed() {
    if (!summary) {
      setError(true);
      return;
    }
    setError(false);
    const magSelect = INTL_MAGAZINES.filter((m) => picked[m.key])
      .map((m) => `${m.code}-${picked[m.key] === "digital2" ? "2D" : picked[m.key] === "print" ? "1P" : "1D"}`)
      .join(", ");

    saveDraft({
      scope: "international",
      amt: summary.total,
      dura: "1yr",
      gift: "",
      mag: "OL-TEO-KJ-INT",
      magSelect,
      selectionList: summary.items,
      currency: "INR",
      toCurrency: currency,
      currencySymbol: symbol,
      languagesSymbol: CURRENCIES[currency]!.locale,
      magazineCode: "15",
      subscriptionType: "international",
    });
    navigate({ to: "/order-form-international" });
  }

  return (
    <div className="ol-page">
      <SiteHeader />
      <div className="ol-container">
        <div className="banner-container1">
          <div className="subdsk-img">
            <img src={BANNERS.digitalDesktop} alt="Outlook international subscription" />
          </div>
          <div className="submob-img">
            <img src={BANNERS.digitalMobile} alt="Outlook international subscription" />
          </div>
        </div>

        <header className="ol-header">
          <h1>Subscription for International Readers</h1>
          <p className="subtitle">Select your favorite magazines — prices shown in your currency</p>
        </header>

        <div className="subscription-tabs">
          <label className="plan-radio">
            <span>Currency</span>
            <select
              className="ol-select"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              style={{ margin: 0, width: "auto" }}
            >
              {Object.keys(CURRENCIES).map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
        </div>

        <p className="scroll-hint">
          <strong>&larr; Scroll horizontally &rarr;</strong>
        </p>
        <div className="magazine-grid">
          {INTL_MAGAZINES.map((mag) => {
            const sel = picked[mag.key] ?? "";
            const editions: { key: Edition; label: string }[] = [
              { key: "print", label: "Print Edition (1 Year)" },
              { key: "digital1", label: "Digital Edition (1 Year)" },
              { key: "digital2", label: "Digital Edition (2 Years)" },
            ];
            return (
              <div key={mag.key} className={`magazine-card ${sel ? "selected" : ""}`}>
                <img src={mag.img} alt={mag.name} className="magazine-image" />
                <div className="magazine-info">
                  <div className="magazine-name">{mag.name}</div>
                  <div className="magazine-details">{mag.details}</div>
                </div>
                <div className="edition-options">
                  {editions.map((e) => (
                    <label className="edition-option" key={e.key}>
                      <input
                        type="checkbox"
                        checked={sel === e.key}
                        onChange={(ev) => {
                          setError(false);
                          setPicked((prev) => ({ ...prev, [mag.key]: ev.target.checked ? e.key : "" }));
                        }}
                      />
                      <span className="edition-label">{e.label}</span>
                      <span className="edition-price">
                        {symbol}
                        {priceOf(mag, e.key)}
                      </span>
                    </label>
                  ))}
                </div>
                <div className="magazine-price">
                  {symbol}
                  {sel ? priceOf(mag, sel) : 0}
                </div>
              </div>
            );
          })}
        </div>

        <div className="selection-summary">
          <h2 className="summary-title">Your Selection Summary</h2>
          <div className="selected-items">
            {summary ? (
              summary.items.map((item) => (
                <div className="selected-item" key={item}>
                  <span>{item}</span>
                </div>
              ))
            ) : (
              <div className="empty-selection">No magazines selected yet</div>
            )}
          </div>
          <div className="deal-summary">
            <div className="deal-row">
              <span style={{ fontWeight: 600 }}>You Pay:</span>
              <span style={{ fontWeight: 700, color: "#d60810", fontSize: "1.2rem" }}>
                {symbol}
                {(summary?.total ?? 0).toLocaleString(CURRENCIES[currency]!.locale)}
              </span>
            </div>
          </div>
          {error && (
            <div className="validation-error">Please select at least one magazine to continue.</div>
          )}
          <button type="button" className="submit-btn pulse" onClick={proceed}>
            Proceed to Checkout
          </button>
        </div>

        <div className="terms">
          <a href="/bundle-subscription">Subscribing from within India? Click here</a>
        </div>
      </div>
    </div>
  );
}
